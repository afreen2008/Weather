# WEATHER-X — Weather Intelligence Dashboard

A responsive weather dashboard built with HTML, CSS, JavaScript, Chart.js and the Open-Meteo APIs.

## Features
- Search worldwide locations using Open-Meteo Geocoding
- Current weather conditions and atmospheric metrics
- Hourly forecast for the next 24 hours
- 7-day daily forecast
- Interactive temperature trend chart
- Celsius/Fahrenheit toggle
- Optional browser geolocation
- Responsive desktop and mobile layout
- Error handling for missing locations and API failures

## Run locally
1. Extract the ZIP file.
2. Open `index.html` in a modern browser.
3. For best results, run a local server (for example, VS Code Live Server).

## APIs
- Geocoding: https://geocoding-api.open-meteo.com/v1/search
- Forecast: https://api.open-meteo.com/v1/forecast
- Documentation: https://open-meteo.com/en/docs

No API key is required for the Open-Meteo free non-commercial API. Chart.js is loaded from jsDelivr CDN.

## Deploy to Vercel
1. Create a GitHub repository and upload `index.html` and `README.md`.
2. In Vercel, select **Add New → Project** and import the repository.
3. Keep the framework preset as **Other**.
4. Deploy. No build command or output directory is required for this static site.
